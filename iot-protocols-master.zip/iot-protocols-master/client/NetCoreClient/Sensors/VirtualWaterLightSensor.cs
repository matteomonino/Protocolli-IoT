﻿using NetCoreClient.ValueObjects;
using System.Text.Json;

namespace NetCoreClient.Sensors
{
    class VirtualWaterLightSensor : IWaterLightSensorInterface, ISensorInterface
    {
        private readonly Random Random;

        public VirtualWaterLightSensor()
        {
            Random = new Random();
        }

        public int WaterLightness()
        {
            return new WaterLightness(Random.Next(100, 200)).Value;
        }

        public string ToJson()
        {
            return JsonSerializer.Serialize(WaterLightness());
        }
    }
}

