﻿namespace NetCoreClient.Sensors
{
    interface IWaterFlowSensorInterface
    {
        int WaterFlowness();
    }
}
