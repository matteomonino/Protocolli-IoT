﻿using NetCoreClient.ValueObjects;
using System.Text.Json;

namespace NetCoreClient.Sensors
{
    class VirtualWaterFlowSensor : IWaterFlowSensorInterface, ISensorInterface
    {
        private readonly Random Random;

        public VirtualWaterFlowSensor()
        {
            Random = new Random();
        }

        public int WaterFlowness()
        {
            return new WaterFlowness(Random.Next(20, 100)).Value;
        }

        public string ToJson()
        {
            return JsonSerializer.Serialize(WaterFlowness());
        }
    }
}

