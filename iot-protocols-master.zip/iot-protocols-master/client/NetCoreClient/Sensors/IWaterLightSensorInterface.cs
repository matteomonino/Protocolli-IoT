﻿namespace NetCoreClient.Sensors
{
    interface IWaterLightSensorInterface
    {
        int WaterLightness();
    }
}
