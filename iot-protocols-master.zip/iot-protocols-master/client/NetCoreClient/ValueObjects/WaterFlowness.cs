﻿namespace NetCoreClient.ValueObjects
{
    internal class WaterFlowness
    {
        public int Value { get; private set; }

        public WaterFlowness(int value)
        {
            this.Value = value;
        }

    }
}
