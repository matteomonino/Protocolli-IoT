﻿namespace NetCoreClient.ValueObjects
{
    internal class WaterLightness
    {
        public int Value { get; private set; }

        public WaterLightness(int value)
        {
            this.Value = value;
        }

    }
}
