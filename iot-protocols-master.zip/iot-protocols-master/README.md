# Corso protocolli di comunicazione IoT

Esempi ed esercizi per il modulo "Adv networking: comunicazione tra oggetti e standard di interoperabilità" - corso IoT 2025.
